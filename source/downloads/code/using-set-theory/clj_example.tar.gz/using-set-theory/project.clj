(defproject using_set_theory "1.0.0-SNAPSHOT"
  :description "Clojure illustrations for 'Using Set Theory' blog article."
  :author "Kyle Isom <coder@kyleisom.net>"
  :url "http://kisom.github.com/2012/01/??/using-set-theory/"
  :main using_set_theory.core
  :dependencies [[org.clojure/clojure "1.3.0"]])