# using set theory
This is the Python illustration for my blog post titled "Using Set Theory."

## Author
Kyle Isom <coder@kyleisom.net>

## License
[ISC / Public Domain dual license.](http://www.brokenlcd.net/license.txt)

